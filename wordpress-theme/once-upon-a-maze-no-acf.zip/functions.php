<?php
/**
 * Once Upon a Maze Theme Functions
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme setup
 */
function once_upon_a_maze_setup() {
    // Add theme support for various features
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'once-upon-a-maze'),
    ));
}
add_action('after_setup_theme', 'once_upon_a_maze_setup');

/**
 * Enqueue scripts and styles
 */
function once_upon_a_maze_scripts() {
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Crimson+Text:wght@400;600&display=swap', array(), null);
    
    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
    
    // Enqueue theme stylesheet
    wp_enqueue_style('once-upon-a-maze-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue theme JavaScript
    wp_enqueue_script('once-upon-a-maze-script', get_template_directory_uri() . '/js/script.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'once_upon_a_maze_scripts');

/**
 * Register widget areas
 */
function once_upon_a_maze_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'once-upon-a-maze'),
        'id'            => 'footer-widgets',
        'description'   => __('Add widgets here to appear in the footer.', 'once-upon-a-maze'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'once_upon_a_maze_widgets_init');

/**
 * Custom post types
 */
function once_upon_a_maze_custom_post_types() {
    // Story Rooms post type
    register_post_type('story_rooms', array(
        'labels' => array(
            'name' => 'Story Rooms',
            'singular_name' => 'Story Room',
            'add_new' => 'Add New Story Room',
            'add_new_item' => 'Add New Story Room',
            'edit_item' => 'Edit Story Room',
            'new_item' => 'New Story Room',
            'view_item' => 'View Story Room',
            'search_items' => 'Search Story Rooms',
            'not_found' => 'No story rooms found',
            'not_found_in_trash' => 'No story rooms found in trash',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-admin-home',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true,
    ));
    
    // Party Rooms post type
    register_post_type('party_rooms', array(
        'labels' => array(
            'name' => 'Party Rooms',
            'singular_name' => 'Party Room',
            'add_new' => 'Add New Party Room',
            'add_new_item' => 'Add New Party Room',
            'edit_item' => 'Edit Party Room',
            'new_item' => 'New Party Room',
            'view_item' => 'View Party Room',
            'search_items' => 'Search Party Rooms',
            'not_found' => 'No party rooms found',
            'not_found_in_trash' => 'No party rooms found in trash',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-birthday-cake',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'once_upon_a_maze_custom_post_types');

/**
 * Remove ACF dependency - use WordPress Customizer instead
 */

/**
 * Customizer additions
 */
function once_upon_a_maze_customize_register($wp_customize) {
    // Add contact information section
    $wp_customize->add_section('contact_info', array(
        'title' => __('Contact Information', 'once-upon-a-maze'),
        'priority' => 30,
    ));
    
    // Email setting
    $wp_customize->add_setting('contact_email', array(
        'default' => 'onceuponamaze@gmail.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('contact_email', array(
        'label' => __('Contact Email', 'once-upon-a-maze'),
        'section' => 'contact_info',
        'type' => 'email',
    ));
    
    // Address setting
    $wp_customize->add_setting('business_address', array(
        'default' => '1000 North Point Cir, Alpharetta, GA 30022',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('business_address', array(
        'label' => __('Business Address', 'once-upon-a-maze'),
        'section' => 'contact_info',
        'type' => 'text',
    ));
    
    // Social media settings
    $wp_customize->add_setting('facebook_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('facebook_url', array(
        'label' => __('Facebook URL', 'once-upon-a-maze'),
        'section' => 'contact_info',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('instagram_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('instagram_url', array(
        'label' => __('Instagram URL', 'once-upon-a-maze'),
        'section' => 'contact_info',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('tiktok_url', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('tiktok_url', array(
        'label' => __('TikTok URL', 'once-upon-a-maze'),
        'section' => 'contact_info',
        'type' => 'url',
    ));
    
    // Add homepage content section
    $wp_customize->add_section('homepage_content', array(
        'title' => __('Homepage Content', 'once-upon-a-maze'),
        'priority' => 35,
    ));
    
    // Hero image setting
    $wp_customize->add_setting('hero_image', array(
        'default' => '',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'hero_image', array(
        'label' => __('Hero Image', 'once-upon-a-maze'),
        'section' => 'homepage_content',
        'mime_type' => 'image',
    )));
    
    // Main title setting
    $wp_customize->add_setting('main_title', array(
        'default' => 'Every Twist Tells a Tale',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('main_title', array(
        'label' => __('Main Title', 'once-upon-a-maze'),
        'section' => 'homepage_content',
        'type' => 'text',
    ));
    
    // Main subtitle setting
    $wp_customize->add_setting('main_subtitle', array(
        'default' => 'Step into a living storybook, where magic winds through enchanted pathways & whimsical rooms as familiar tales come to life.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('main_subtitle', array(
        'label' => __('Main Subtitle', 'once-upon-a-maze'),
        'section' => 'homepage_content',
        'type' => 'textarea',
    ));
    
    // Main description setting
    $wp_customize->add_setting('main_description', array(
        'default' => 'Next door to FairyTale Village, this all-new walk-through experience invites you to wander, wonder, and rediscover your favorite childhood stories — one twist at a time.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('main_description', array(
        'label' => __('Main Description', 'once-upon-a-maze'),
        'section' => 'homepage_content',
        'type' => 'textarea',
    ));
}
add_action('customize_register', 'once_upon_a_maze_customize_register');

/**
 * Helper function to get theme option
 */
function get_theme_option($option_name, $default = '') {
    return get_theme_mod($option_name, $default);
}

/**
 * Add custom body classes
 */
function once_upon_a_maze_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    if (is_page('contact')) {
        $classes[] = 'contact-page';
    }
    return $classes;
}
add_filter('body_class', 'once_upon_a_maze_body_classes');

/**
 * Custom excerpt length
 */
function once_upon_a_maze_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'once_upon_a_maze_excerpt_length');

/**
 * Custom excerpt more
 */
function once_upon_a_maze_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'once_upon_a_maze_excerpt_more');

/**
 * Add support for custom logo
 */
function once_upon_a_maze_custom_logo_setup() {
    add_theme_support('custom-logo', array(
        'height'      => 90,
        'width'       => 90,
        'flex-height' => true,
        'flex-width'  => true,
    ));
}
add_action('after_setup_theme', 'once_upon_a_maze_custom_logo_setup');

/**
 * Contact form handler
 */
function once_upon_a_maze_contact_form_handler() {
    if (isset($_POST['contact_form_submit'])) {
        $name = sanitize_text_field($_POST['contact_name']);
        $email = sanitize_email($_POST['contact_email']);
        $message = sanitize_textarea_field($_POST['contact_message']);
        
        if (!empty($name) && !empty($email) && !empty($message)) {
            $to = get_theme_option('contact_email', 'onceuponamaze@gmail.com');
            $subject = 'New Contact Form Submission from ' . $name;
            $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
            $headers = array('Content-Type: text/plain; charset=UTF-8');
            
            if (wp_mail($to, $subject, $body, $headers)) {
                wp_redirect(add_query_arg('contact', 'success', wp_get_referer()));
                exit;
            } else {
                wp_redirect(add_query_arg('contact', 'error', wp_get_referer()));
                exit;
            }
        }
    }
}
add_action('init', 'once_upon_a_maze_contact_form_handler');

/**
 * Fallback menu function
 */
function once_upon_a_maze_fallback_menu() {
    echo '<ul class="nav-menu">';
    echo '<li><a href="' . home_url() . '">Home</a></li>';
    echo '<li><a href="' . home_url('/contact') . '">Contact</a></li>';
    echo '<li><a href="#" class="cta-button">Get Tickets</a></li>';
    echo '</ul>';
}

/**
 * Theme is ready - no additional plugins required
 */
?>
